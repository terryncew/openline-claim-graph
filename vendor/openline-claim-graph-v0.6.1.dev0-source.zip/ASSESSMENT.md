# Assessment

## Prospective Decision Recall — 0.6.0.dev0

The 0.5.2 result is frozen. The next ratchet tests the missing upstream assumption rather than adding another propagation feature: whether a receiver can cheaply confirm enough dependency state at acceptance time for later revocations to become selectively reviewable.

The benchmark is designed to distrust the manifest. Conventional pre-trigger records and an eligible-basis universe are sealed separately, and controlled revocations are sampled from that independent universe after the manifest stream is frozen. A basis can therefore be present in the real decision record, omitted from the tiny manifest, later lose standing, and count as a Decision Recall miss under blind gold.
The aggregator also rejects duplicated or content-tampered score artifacts, grades the randomized controlled stratum separately from natural events, requires role-separated blinded adjudication, and requires mixed REOPEN/SURVIVE events rather than allowing an all-positive benchmark to masquerade as selectivity.

The checked conformance fixture deliberately injects that exact failure. It proves custody and scoring mechanics can expose an omitted dependency; it does not provide evidence that real capture is cheap, real manifests are complete enough, or the economics work. The verifier was deliberately made module-free after the first version was found to import the candidate implementation; it now independently reproduces the fixture under Python isolated mode. Gold packets source the accepted decision statement from the separately sealed conventional record, not the manifest. Review-time receipts are bound to content-addressed system-specific workloads rather than free-floating declared milliseconds.

Those repairs remove circular mechanics from the test harness; they do not create empirical evidence. Product promotion remains unearned until a real prospective stream crosses the frozen bar.

The eligible-basis challenge universe is now separately custody-bound. Promotion requires a catalog declared as enumerated from conventional pre-trigger records only, with the prospective manifest hidden and the catalog builder role-separated from capture actors. This closes an easy self-test loophole—constructing the challenge universe from what the product already declared—but it remains partly procedural: software can bind the declaration and identities, not prove what a human secretly saw.

Full History is also no longer an oracle. The benchmark records blinded baseline reviewer dispositions for Full History and Flat Search, separately from independent gold. An authored conformance control makes the Full History reviewer miss one warranted reopening that Decision Recall catches; this is calibration of the scorer, not empirical evidence. Promotion additionally requires the policy itself to have been frozen before capture started.

## Mixed real temporal selectivity corpus — 0.5.1

The first mixed corpus is now graded under a promotion rule declared before gold construction: frozen Evidence Recall must achieve at least 95% reconsideration recall, reduce review load by at least 40% versus Review-All Reachability, and add no missed reopenings.

The corpus reuses the Shah/Darwish episode unchanged and adds a Narayan SIRT2 retraction episode. The latter contains one pre-cutoff Nature News & Views summary admitted as HARD and one pre-cutoff Vitner direct-citation candidate left UNADMITTED because the citation context is experimental-method use rather than conclusion-level reliance. A later independent citation audit supplies one affirmative `REOPEN` and one affirmative `NO_REOPEN`.

Result: Direct Lookup catches 2/3 warranted reopenings with review load 3. Review-All catches 3/3 with review load 4 and one unnecessary review. Frozen Evidence Recall catches 3/3 with review load 3 and zero unnecessary reviews. Evidence Recall therefore cuts review load 25% while retaining 100% recall, but misses the predeclared 40% materiality bar.

Verdict: `NO_PROMOTION`. This is the first real case-level evidence that typed authority can buy back some attention rather than merely changing severity labels, but one saved review across four targets is not enough to justify the product thesis. The engine remains byte-for-byte frozen and the shortfall is not repaired.

## First real temporal case — 0.5.0.dev1

The first real historical temporal episode is now graded. The accepted state is the 2021 Shah intravenous-iron meta-analysis, frozen the day before the Darwish trial retraction. The later 2025 JAMA correction records an explicit reanalysis without the retracted study and no change in reported results.

Direct Lookup catches one of the two warranted reopenings. Review-All Reachability and frozen Evidence Recall catch both, but both wake two targets. Evidence Recall therefore saves zero reviews. The engine is unchanged from `0.5.0.dev0`; no rescue semantics were added.

Verdict: `NO_PROMOTION`. This is real temporal mechanism contact, not a selectivity win. Because the episode has only positive gold labels, it does not estimate false-review precision. A corpus containing affirmative later `REOPEN` and `NO_REOPEN` outcomes is still required to test whether structured dependency state buys back attention rather than merely matching Review-All.

## Temporal holdout update — 0.5.0.dev0

The benchmark infrastructure advances, not Evidence Recall. The new evaluator can freeze a pre-event accepted state, bind later records without exposing them to prediction, compare Direct Lookup / Review-All Reachability / frozen Evidence Recall, and score later documented reconsideration with explicit human-review cost. The synthetic fixture proves those mechanics only.

The product thesis remains unpromoted until a real historical corpus shows that Evidence Recall catches later warranted reopenings with materially less review than simply escalating every reachable item. A tie with Review-All Reachability is a failure of the selectivity thesis even if Evidence Recall produces safer labels.

The historical-reconstruction blindfold is partly mechanical and partly procedural. Timestamps, content commitments, and sealed artifacts can be verified; the code cannot prove that a corpus constructor did not consult future information while assigning pre-cutoff semantic edges. That construction process must therefore be independently auditable in a real run.

## Verdict

The idea survives as a working integrity, lineage, and deterministic source-impact mechanism. A small independent-gold development check shows that one source-to-graph mapping pass can recover signal on a constrained missing-premise task. A separate natural-material case produces a readable review of five published abstract/main-text conflicts later confirmed by an independent correction. Version `0.2.0.dev1` applies that real correction to an accepted dependency specimen and computes the downstream evidence blast radius without an LLM judge. Version `0.3.0.dev0` adds a second native operation: reproduce narrowly typed framing devices from exact text while preventing model interpretation from self-promoting into a verdict.

The durable correction to Coherence Dynamics is architectural:

> Do not compress reasoning into a sender-certified scalar. Preserve its typed structure, version it, and let a receiver decide what that structure earns.

The graph has now earned one additional job that does not depend on proving it is easier to comprehend than prose: when an admitted source changes, it can mechanically identify downstream claims whose admitted basis no longer survives, preserve claims with an admitted alternative basis, and route inferred-edge exposure to review rather than hard quarantine.

## What the implementation established

The prototype can create a small signed commitment to a larger graph state; reproduce its deterministic root; bind it to source commitments; disclose and verify a bounded graph/source slice; retain branches; expose incompatible slots; and prevent a merge from silently deleting or reconciling conflicting claims.

It also closes the easiest provenance forgery. A producer cannot label a paraphrase as `QUOTE` unless the claim text exactly matches the declared UTF-8 source span. This is narrower than semantic extraction fidelity but materially stronger than trusting `EXTRACTED` because the producer typed it.

The receipt-size design initially contained every source commitment and every warning, which made it grow with the graph. That failed the stated efficiency goal. Both collections were replaced with Merkle roots, counts, and compact warning categories. Only projection-relevant source commitments travel with inclusion proofs.

The new Decision Review renderer adds no semantic judgment. It verifies the composed bundle first and fails closed on a broken key pin, signature, source, graph, projection, disclosure, or binding. For an admitted bundle it renders the declared conflicts, exact source spans, policy limits, and lineage as one static HTML file. It escapes source content rather than executing it.

The Evidence Recall engine likewise adds no semantic judgment. A receiver explicitly names hard, advisory, and unadmitted dependency relations. The engine computes a least fixed point of grounded surviving support, then classifies only event-touched claims. This prevents an ungrounded support cycle from rescuing itself and prevents one corrected source from poisoning a claim that retains an admitted alternative basis.

Frame Ledger separates mechanical devices from semantic interpretations. Exact lexical, local-grammar, and declared scoped-absence findings reproduce under one content-addressed ruleset. An AI may propose higher-level interpretations, but exact-quote import, signed execution identities, non-self-review, distinct declared-family quorum, challenge blocking, and receiver-selected human mode control admission. Even an admitted semantic finding remains advisory. Truth, lying, intent, fairness, rationalization, propaganda, and reader effect are prohibited verdicts rather than hidden scores.

## What remains outside the instrument

The prototype cannot verify that:

- a paraphrase preserves meaning;
- an inferred relation follows from its cited material;
- the ontology divides the subject fairly;
- a bounded projection did not omit decisive context;
- the resulting map improves a real receiver's judgment.
- the admitted dependency graph is complete;
- the event-to-affected-span mapping is semantically correct;
- maintaining the dependency state saves enough review cost to justify adoption.
- the Frame Ledger ruleset is complete, politically neutral, or superior to existing framing taxonomies;
- separately named model families are actually independent;
- any current frontier or open-weight model can perform the advisory task reliably;
- the one-headline surface represents the article body.

An extraction-process receipt containing a model ID, prompt digest, and source digest would improve reproducibility. It would **not** prove semantic fidelity. It identifies the machine that made the translation; it does not make the translation correct.

## What the ARCT check adds

The development fixture uses 24 deterministically selected rows from the independently annotated Argument Reasoning Comprehension Task. The mapper saw each premise, claim, two candidate warrants, and debate context without the correct-warrant label. One frozen pass selected 21/24 upstream labels correctly. Executable controls then show that the graph representation commits to the selection: gold mappings score 24/24, opposite mappings score 0/24, and all 24 gold/decoy pairs have different state roots.

This is useful evidence against the claim that the mapping step can only echo a fixture authored inside OpenLine. It remains deliberately weak evidence for anything larger. The task is multiple-choice, the sample is small, the benchmark is public, the model pass was not replicated, and the repository file was assembled after the labels were revealed. Most importantly, no receiver compared a graph with prose.

## What the natural-material case adds

The PLOS ONE example uses the original article's published abstract and main-results passages without showing the later correction to the receiver bundle. The graph represents five conflicting quantities, the signed bundle verifies, and the HTML review reproduces those fault lines with exact spans. The later correction explicitly identifies the same abstract/main-text inconsistency.

That is evidence of contact with natural material and an external veto, but not of product value. The extraction was manual, only one case was used, and no blinded receiver comparison was run. The honest result is: the mechanism and surface work on this case; superiority remains untested.

## What Evidence Recall adds

The PLOS correction is admitted as a content-addressed source-status event against a signed accepted-state specimen. Direct source lookup exposes five abstract claims. The dependency engine proposes seven claims for quarantine, reaching two downstream claims that direct lookup misses. It preserves one related claim with an admitted alternative main-text basis, routes one advisory-edge path to unresolved review, leaves six claims untouched, and identifies one accepted decision to reopen.

An independent verifier that does not import the impact engine reproduces the graph and event commitments, Ed25519 receipt binding, classification sets, witness paths, and rendered review hash. A separate 2,000-case randomized differential probe covers cycles, exact affected spans, required dependencies, alternative support, and advisory paths with zero mismatches.

This is real mechanism contact, not independent dependency discovery. The article and correction are natural material; the downstream accepted-state graph is authored for the specimen. The earned claim is conditional correctness: given that exact state, event, and receiver policy, the impact report is exact and reproducible.

## What Frame Ledger adds

The checked-in Washington Post specimen audits only the supplied headline. Seven findings reproduce: one conflict lexeme, one co-occurrence cue, two issue-frame lexemes, one narrow local-attribution-pattern absence, and two receiver-declared term-set absences. A stdlib-only verifier that does not import the candidate implementation reproduces 20 content, span, rule, policy, classification, and rendered-output checks.

This is a successful mechanism test and nothing larger. The article body is absent. The ruleset has not been validated against Media Frames Corpus or NewsWCL50. No frontier/open-weight model was called, and the model registry is an unrun candidate list. The autonomous path is nevertheless complete and tested with controlled endpoint fixtures: proposal, exact quote import, signature, two-family review, challenge handling, receiver-policy admission, and fail-closed rendering can run without a mandatory human action.

## Relation to the prior work

DSM already contained the useful beginning: explicit nodes and edges, temporal graph hashes, previous-state references, and separate provenance channels. Its scalar stress/coherence layer did not survive external testing. The prototype keeps the graph and custody ideas and removes the scores.

The original OLP receipt idea also survives, but in a narrower form. The receipt does not carry the whole graph or certify a global state of knowledge. It commits to one graph state and provides a receiver-scoped projection with verifiable lineage.

The wallet is therefore not a truth ledger. It is custody for evolving representations—closer to Git history for arguments than a database of certified facts.

## Current disposition

`KEEP_AS_EXPERIMENTAL_ARTIFACT`

`DO_NOT_CLAIM_EXTERNAL_DECISION_VALUE`

`DO_NOT_ADD_RDF_OR_STANDARDS_INFRASTRUCTURE_YET`

`SOURCE_IMPACT_MECHANISM_VERIFIED_ON_REAL_EVENT_AUTHORED_DEPENDENCIES`

`FRAME_DEVICE_MECHANISM_REPRODUCED_ON_ONE_NATURAL_HEADLINE`

`AUTONOMOUS_REVIEW_CONTRACT_IMPLEMENTED_MODEL_EFFICACY_UNTESTED`

The immediate useful path is bounded evidence recall: signed accepted state, an externally grounded source-status event, explicit receiver admission of dependency edges, deterministic exposure, and a proposed review that cannot mutate accepted state. The next external-value test is operational rather than cognitive: on a real maintained state, does the mechanism catch required reconsideration that direct source lookup misses without creating unacceptable review volume?

The machine-receiver harness remains available for any future presentation/comprehension claim. It does not gate the source-impact mechanism and cannot inherit its result.

The human receiver protocol remains a dormant branch for any future claim about human comprehension. A machine-receiver win cannot be laundered into that claim.

The receiver-discovery pilot protocol is included, but its analyzed case pack is empty and it has not been run. The ARCT fixture is a development positive control and is structurally barred from being counted as Stage 1. The protocol fixes case admission, custody, the three-arm estimand, between-receiver assignment, scoring, and Stage 1/Stage 2 boundaries before any receiver result exists. That is experimental discipline, not evidence of value.

No paid experiment API calls or automated receiver trials were performed. One interactive model mapping pass from the earlier ARCT development check was scored against withheld labels; its three errors remain disclosed.

## Comparative benchmark status — 0.4.0.dev0

The next claim is now forced through a three-way external comparison rather than another feature. The benchmark freezes Direct Lookup, naive transitive taint, and the shipped Evidence Recall engine. Public inputs, receiver edge authority, predictions, and external gold are separately bound so gold is unnecessary for prediction generation.

The canonical main corpus is Schneider et al.'s second-generation Matsuyama citation-context dataset. The importer is ready and fail-closed, but the canonical CSV bytes could not be acquired inside this build environment; the van der Vet supplementary DOT is likewise not bundled. Therefore **no case-level empirical advantage is claimed in this release**.

A published-count diagnostic is checked in and independently reproduced. It is already informative: the 23 Schneider positives are non-direct and therefore missed by direct lookup; blind transitive taint would act on the whole 152-item accessible neighborhood; with ordinary second-generation citation edges kept advisory, Evidence Recall avoids turning those links directly into hard quarantine but still sends the neighborhood to review. After conservatively excluding all four possible direct-overlap records from false-positive counting, naive taint still has at least 125 hard over-taint candidates and Evidence Recall still has at least 125 unnecessary unresolved-review candidates. Both carry a 152-item total review load at this aggregate level.

That is not a win. It is the benchmark doing its job: **typed authority has not earned selective reviewer-load reduction from citation topology alone.** The case-level run must determine whether a blind, independently constructed authority file can separate the 23 consequential paths from the rest. If it cannot, the current mechanism should not be promoted as an empirical advantage over simpler provenance systems.

The JAMA stratum remains diagnostic rather than scored as false quarantine. A retracted constituent can legitimately force recomputation of an exact aggregate even when the recomputed number happens not to change. The stress test asks whether categorical relation semantics are selective enough for quantitative aggregation, not whether quarantine predicts a numerical flip.

## 0.5.2 replication verdict

The frozen temporal-selectivity behavior now crosses its predeclared product-candidate bar on the checked-in replication corpus. Across five trigger episodes and fourteen explicit case-level targets, Evidence Recall catches 8/8 warranted reopenings while reviewing 8 targets versus Review-All's 14, a 42.85% reduction with zero additional misses. Positive savings recur in four of five trigger episodes.

Verdict: `PROMOTION`, narrowly defined as promotion of temporal selectivity to a serious product candidate. The evidence does not establish a moat or broad independent-domain replication. Three of the five triggers belong to one Sato misconduct family and rely on one later manual audit; the packs were reconstructed retrospectively. No engine semantics were changed to obtain the result.
